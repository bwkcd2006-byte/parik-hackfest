import { useEffect, useMemo, useState, type FormEvent, type ReactNode, type CSSProperties } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import { Route, Switch, useLocation, Router as WouterRouter, Link } from 'wouter';
import {
  Activity, ArrowRight, BarChart3, BookOpen, BusFront,
  CalendarDays, Check, ChevronRight, CircleHelp, Cloud,
  Leaf, Lightbulb, Menu, Plus, Recycle, ShieldCheck, Sprout, Trash2, TrendingDown,
  TreePine, Zap,
} from 'lucide-react';
import {
  Area, AreaChart, Bar, BarChart, CartesianGrid, Cell, Pie, PieChart,
  ResponsiveContainer, Tooltip as ChartTooltip, XAxis, YAxis,
} from 'recharts';

type Category = 'transport' | 'electricity' | 'waste';
type ActivityRecord = {
  id: string; category: Category; quantity: number; mode?: string; label?: string;
  date: string; emissions: number; unit: string; factor: number;
};
const STORAGE_KEY = 'greencampus.activity.v1';
// Replace these demo assumptions with documented local factors before formal reporting.
// Units: kg CO2e per activity unit. Walking/cycling use zero direct operational emissions.
const FACTORS: Record<Category, number> = { transport: 0.089, electricity: 0.42, waste: 0.58 };
const CATEGORIES: { id: Category; name: string; color: string; icon: typeof BusFront }[] = [
  { id: 'transport', name: 'Transport', color: '#3d7854', icon: BusFront },
  { id: 'electricity', name: 'Electricity', color: '#d3a94d', icon: Zap },
  { id: 'waste', name: 'Waste', color: '#79a9a0', icon: Recycle },
];
const queryClient = new QueryClient();
const dateKey = (date: Date) => {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
};
const today = dateKey(new Date());
const fmt = (n: number) => new Intl.NumberFormat('en-US', { maximumFractionDigits: 1 }).format(n);
const round = (n: number) => Math.round(n * 10) / 10;

function readRecords(): { records: ActivityRecord[]; issue: string } {
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return { records: [], issue: '' };
    const parsed: unknown = JSON.parse(raw);
    if (!Array.isArray(parsed) || parsed.some((r) => !r || typeof r.id !== 'string' ||
      !['transport', 'electricity', 'waste'].includes(r.category) ||
      !Number.isFinite(r.quantity) || !Number.isFinite(r.emissions) || typeof r.date !== 'string')) {
      return { records: [], issue: 'Saved activity could not be read. Your browser data may be damaged.' };
    }
    return { records: parsed as ActivityRecord[], issue: '' };
  } catch {
    return { records: [], issue: 'Local storage is unavailable or saved data is damaged. You can still use the calculator for this visit.' };
  }
}

function App() {
  const initial = useMemo(readRecords, []);
  const [records, setRecords] = useState<ActivityRecord[]>(initial.records);
  const [storageIssue, setStorageIssue] = useState(initial.issue);
  const [saveIssue, setSaveIssue] = useState('');
  const [location] = useLocation();

  useEffect(() => {
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(records));
      setSaveIssue('');
    } catch {
      setSaveIssue('Could not save to this browser. Your current entries will remain until you leave this page.');
    }
  }, [records]);

  const totals = useMemo(() => records.reduce((acc, item) => {
    acc[item.category] += item.emissions;
    return acc;
  }, { transport: 0, electricity: 0, waste: 0 }), [records]);
  const total = totals.transport + totals.electricity + totals.waste;
  // A demo engagement score based on logging activity and category coverage,
  // not a claim about measured emissions reductions or campus performance.
  const score = records.length === 0 ? 0 : Math.min(100,
    20 + new Set(records.map((record) => record.category)).size * 20 + Math.min(records.length, 10) * 3);
  const largest = CATEGORIES.reduce((a, b) => totals[a.id] >= totals[b.id] ? a : b);
  const hasData = records.length > 0;

  const addRecord = (record: ActivityRecord) => setRecords((prev) => [record, ...prev]);
  const removeRecord = (id: string) => setRecords((prev) => prev.filter((item) => item.id !== id));
  const resetStorage = () => {
    try {
      window.localStorage.removeItem(STORAGE_KEY);
      setRecords([]);
      setStorageIssue('');
      setSaveIssue('');
    } catch {
      setStorageIssue('Browser storage is still unavailable. Please check your browser privacy settings.');
    }
  };

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
          <ErrorBoundary resetKey={location}>
            <Shell>
              <Switch>
                <Route path="/" component={() => <Dashboard records={records} totals={totals} total={total} score={score} largest={largest} onRemove={removeRecord} />} />
                <Route path="/calculator" component={() => <Calculator onAdd={addRecord} onRemove={removeRecord} records={records} />} />
                <Route path="/insights" component={() => <Insights records={records} totals={totals} total={total} score={score} />} />
                <Route path="/about" component={About} />
                <Route component={NotFound} />
              </Switch>
              <NoticeFooter />
              {(storageIssue || saveIssue) && <div className="gc-content gc-notice" role="alert" data-testid="status-storage-error">
                <CircleHelp size={16} /><div><strong>Browser storage notice.</strong> {saveIssue || storageIssue}
                  {storageIssue && <button className="gc-quiet-btn" onClick={resetStorage} data-testid="button-clear-storage">Clear saved data</button>}
                </div>
              </div>}
            </Shell>
          </ErrorBoundary>
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

function Shell({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  const nav = [
    { path: '/', label: 'Dashboard', icon: BarChart3 },
    { path: '/calculator', label: 'Carbon calculator', icon: Plus },
    { path: '/insights', label: 'Insights', icon: TrendingDown },
    { path: '/about', label: 'About GreenCampus', icon: BookOpen },
  ];
  return <div className="gc-shell">
    <aside className="gc-sidebar">
      <Link href="/" className="gc-brand" data-testid="link-brand">
        <span className="gc-brand-mark"><TreePine size={22} /></span>
        <span><span className="gc-brand-name">GreenCampus</span><span className="gc-brand-sub">Small choices. Shared impact.</span></span>
      </Link>
      <div className="gc-nav-label">Your campus</div>
      <nav className="gc-nav" aria-label="Main navigation">
        {nav.map(({ path, label, icon: Icon }) => <Link key={path} href={path} className={location === path ? 'active' : ''} aria-current={location === path ? 'page' : undefined} data-testid={`link-${label.toLowerCase().replaceAll(' ', '-')}`}>
          <Icon size={17} strokeWidth={1.8} />{label}
        </Link>)}
      </nav>
      <div className="gc-side-bottom"><strong>One campus, many choices.</strong>A shared estimate of the everyday things we can change together.</div>
    </aside>
    <main className="gc-main">
      <header className="gc-topbar">
        <div className="gc-crumb"><span>GreenCampus</span><ChevronRight size={13} style={{ verticalAlign: 'middle', margin: '0 5px' }} /><strong>{nav.find((n) => n.path === location)?.label ?? 'Campus'}</strong></div>
        <div className="gc-date-pill"><CalendarDays size={14} /> Activity log · stored on this device</div>
      </header>
      <div className="gc-content">{children}</div>
      <nav className="gc-mobile-nav" aria-label="Mobile navigation">
        {nav.map(({ path, label, icon: Icon }) => <Link key={path} href={path} className={location === path ? 'active' : ''} data-testid={`mobile-link-${path.slice(1) || 'dashboard'}`}><Icon size={17} /><span>{label.replace('GreenCampus', '')}</span></Link>)}
      </nav>
    </main>
  </div>;
}

function PageHeading({ eyebrow, title, subtitle, action }: { eyebrow: string; title: string; subtitle: string; action?: ReactNode }) {
  return <div className="gc-title-row"><div><div className="gc-eyebrow">{eyebrow}</div><h1 className="gc-title">{title}</h1><p className="gc-subtitle">{subtitle}</p></div>{action}</div>;
}

function NoticeFooter() {
  return <footer className="gc-content gc-footer"><span>GreenCampus · A practical campus sustainability hub</span><span>Every number is an estimate, not a measured campus total.</span></footer>;
}

function Dashboard({ records, totals, total, score, largest, onRemove }: { records: ActivityRecord[]; totals: Record<Category, number>; total: number; score: number; largest: typeof CATEGORIES[number]; onRemove: (id: string) => void }) {
  const [chartCategory, setChartCategory] = useState<Category | 'all'>('all');
  const hasData = records.length > 0;
  const chartData = useMemo(() => {
    const days = Array.from({ length: 7 }, (_, i) => {
      const date = new Date(); date.setDate(date.getDate() - (6 - i));
      return { key: dateKey(date), day: date.toLocaleDateString('en-US', { weekday: 'short' }), transport: 0, electricity: 0, waste: 0 };
    });
    records.forEach((r) => { const d = days.find((day) => day.key === r.date); if (d) d[r.category] += r.emissions; });
    return days.map((d) => ({ ...d, emissions: chartCategory === 'all' ? d.transport + d.electricity + d.waste : d[chartCategory] }));
  }, [records, chartCategory]);
  const recommendation = !records.length
    ? ['Start with one small entry', 'Add a commute, electricity use, or waste estimate to see a practical next step tailored to your campus activity.']
    : largest.id === 'transport'
      ? ['Try a shared or active commute', 'Replace one solo car trip this week with a bus, carpool, cycle, or walk. Small repeatable changes add up.']
      : largest.id === 'electricity'
        ? ['Switch off the unnoticed loads', 'Turn off lights and screens in empty rooms, and enable sleep mode on shared equipment after classes.']
        : ['Make sorting the easy choice', 'Set up a clearly labelled recycling point where waste is created, and avoid single-use items at your next event.'];
  const label = records.length ? largest.name : 'your next step';
  const factorFoot = 'Illustrative factors · not measured campus data';
  return <>
    <PageHeading eyebrow="Campus pulse · today" title="Better choices, together." subtitle="A living estimate of the everyday footprint we can shape as a campus." action={<Link href="/calculator" className="gc-primary-btn" data-testid="link-add-activity"><Plus size={15} /> Log an activity</Link>} />
    <section className="gc-kpis" aria-label="Campus footprint summary">
      <div className="gc-card gc-kpi-main">
        <div className="gc-kpi-label"><Cloud size={14} /> Estimated footprint</div>
        <div className="gc-kpi-value" data-testid="value-total-emissions">{fmt(total)} <span className="gc-kpi-unit">kg CO₂e</span></div>
        <div className="gc-kpi-foot">{hasData ? `${records.length} logged ${records.length === 1 ? 'activity' : 'activities'} · ${factorFoot}` : 'Add an activity to begin your estimate'}</div>
        <div className="gc-progress" aria-label={`Sustainability score ${score} out of 100`}><span style={{ width: `${score}%` }} /></div>
      </div>
      {CATEGORIES.map(({ id, name, icon: Icon }) => <div className="gc-card" key={id}>
        <div className="gc-kpi-label"><Icon size={14} /> {name}</div>
        <div className="gc-kpi-value" data-testid={`value-${id}-emissions`}>{fmt(totals[id])} <span className="gc-kpi-unit">kg</span></div>
        <div className="gc-kpi-foot">{total ? `${Math.round(totals[id] / total * 100)}% of your estimate` : 'No entries yet'}</div>
      </div>)}
    </section>
    <section className="gc-mid-grid">
      <div className="gc-card">
        <div className="gc-card-head"><div><h2 className="gc-card-title">Footprint over the week</h2><div className="gc-card-caption">Daily activity · kg CO₂e</div></div>
          <select aria-label="Chart category" value={chartCategory} onChange={(e) => setChartCategory(e.target.value as Category | 'all')} data-testid="select-chart-category" style={{ border: '1px solid #e4ece4', borderRadius: 7, padding: '7px 9px', color: '#55705e', background: '#fff', fontSize: 10 }}>
            <option value="all">All categories</option>{CATEGORIES.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
        </div>
        {!hasData ? <div className="gc-empty"><div className="gc-empty-mark"><BarChart3 size={18} /></div>Your week is a fresh page.<br />Log an activity to see the trend take shape.</div> :
          <div className="gc-chart-wrap" data-testid="chart-weekly-emissions"><ResponsiveContainer width="100%" height="100%">
            <AreaChart data={chartData} margin={{ top: 8, right: 10, left: -18, bottom: 0 }}>
              <defs><linearGradient id="emissionFill" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#4f8a62" stopOpacity={0.18} /><stop offset="95%" stopColor="#4f8a62" stopOpacity={0} /></linearGradient></defs>
              <CartesianGrid stroke="#edf1ed" vertical={false} />
              <XAxis dataKey="day" axisLine={false} tickLine={false} tick={{ fill: '#8b998e', fontSize: 10 }} />
              <YAxis axisLine={false} tickLine={false} tick={{ fill: '#8b998e', fontSize: 9 }} />
              <ChartTooltip formatter={(v: number) => [`${fmt(v)} kg CO₂e`, 'Estimate']} contentStyle={{ borderRadius: 9, border: '1px solid #e1eae2', fontSize: 11 }} />
              <Area type="monotone" dataKey="emissions" stroke="#3d7854" strokeWidth={2.5} fill="url(#emissionFill)" activeDot={{ r: 5 }} />
            </AreaChart>
          </ResponsiveContainer></div>}
        <div className="gc-chart-legend"><span className="gc-legend"><span className="gc-dot" style={{ background: '#3d7854' }} /> Estimated activity</span><span className="gc-legend">No activity is inferred for unlogged days</span></div>
      </div>
      <div className="gc-card gc-score-card">
        <div className="gc-card-head"><div><h2 className="gc-card-title">Campus sustainability score</h2><div className="gc-card-caption">A simple engagement indicator</div></div><Sprout size={18} color="#568461" /></div>
        <div className="gc-score-wrap"><div className="gc-score-ring" style={{ '--score-angle': `${score * 3.6}deg` } as CSSProperties}><strong data-testid="value-sustainability-score">{score}</strong></div>
          <div className="gc-score-description"><b>{score > 65 ? 'Good momentum' : score > 30 ? 'Building the habit' : 'A fresh start'}</b>{hasData ? 'Your activity log is becoming a useful picture of campus choices.' : 'Each logged choice helps build a clearer picture.'}</div>
        </div>
        <div className="gc-score-meta"><span>Activity + category coverage</span><strong>Demo score, not a rating</strong></div>
      </div>
    </section>
    <section className="gc-lower-grid">
      <div className="gc-card">
        <div className="gc-card-head"><div><h2 className="gc-card-title">Recent activity</h2><div className="gc-card-caption">Saved on this device</div></div><Link href="/calculator" className="gc-tip-action" data-testid="link-view-all-activity">Add activity <ArrowRight size={13} /></Link></div>
        {records.length === 0 ? <div className="gc-empty"><div className="gc-empty-mark"><Leaf size={18} /></div>No activities yet.<br />Your first entry starts the shared estimate.</div> : records.slice(0, 4).map((r) => <ActivityRow key={r.id} record={r} onRemove={onRemove} />)}
      </div>
      <div className="gc-card gc-tip">
        <div className="gc-tip-tag">A practical next step · {label}</div>
        <h3>{recommendation[0]}</h3><p>{recommendation[1]}</p>
        <Link href="/calculator" className="gc-tip-action" data-testid="link-recommendation-log">Log a small change <ArrowRight size={13} /></Link>
        <div style={{ borderTop: '1px solid #dbe7d9', marginTop: 17, paddingTop: 12, color: '#8a9888', fontSize: 9 }}>Recommendations are general ideas based on your largest logged category.</div>
      </div>
    </section>
    <section className="gc-card">
      <div className="gc-card-head"><div><h2 className="gc-card-title">Campus community</h2><div className="gc-card-caption">A little friendly inspiration</div></div><span style={{ background: '#f7f4e7', color: '#8c7840', borderRadius: 20, padding: '6px 9px', fontSize: 9, fontWeight: 800, letterSpacing: '.7px' }}>SAMPLE DATA</span></div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 10 }}>
        {[['01', 'Library & Learning', 'More active commutes'], ['02', 'Arts Collective', 'Reuse at every event'], ['03', 'North Hall', 'Lights out after study']].map(([rank, group, motto]) => <div key={rank} style={{ display: 'flex', gap: 10, alignItems: 'center', padding: '10px 0' }}>
          <span style={{ color: '#8ca091', font: '700 12px var(--app-font-serif)' }}>{rank}</span><span style={{ width: 29, height: 29, borderRadius: 9, background: '#edf5ed', color: '#40734c', display: 'grid', placeItems: 'center' }}><Leaf size={14} /></span>
          <span style={{ fontSize: 11, color: '#355642', fontWeight: 700 }}>{group}<small style={{ display: 'block', color: '#91a095', fontWeight: 400, marginTop: 3 }}>{motto}</small></span>
        </div>)}
      </div>
    </section>
    <EstimatesNotice />
  </>;
}

function ActivityRow({ record, onRemove }: { record: ActivityRecord; onRemove: (id: string) => void }) {
  const cat = CATEGORIES.find((c) => c.id === record.category)!;
  const Icon = cat.icon;
  return <div className="gc-activity-row" data-testid={`row-activity-${record.id}`}>
    <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}><span style={{ width: 30, height: 30, borderRadius: 9, display: 'grid', placeItems: 'center', background: '#eff5ef', color: cat.color }}><Icon size={15} /></span>
      <div><div className="gc-activity-name">{record.label || `${cat.name}${record.mode ? ` · ${record.mode}` : ''}`}</div><div className="gc-activity-meta">{new Date(`${record.date}T12:00:00`).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })} · {fmt(record.quantity)} {record.unit}</div></div>
    </div>
    <div style={{ display: 'flex', alignItems: 'center' }}><div className="gc-activity-value">{fmt(record.emissions)} kg CO₂e</div><button className="gc-delete" aria-label={`Remove ${record.label || cat.name} activity`} onClick={() => onRemove(record.id)} data-testid={`button-remove-${record.id}`}><Trash2 size={14} /></button></div>
  </div>;
}

function EstimatesNotice() {
  return <div className="gc-notice" role="note"><ShieldCheck size={15} style={{ flexShrink: 0, marginTop: 1 }} /><div><strong>Estimate, not measurement.</strong> Calculations use illustrative activity factors only. Replace them with verified local factors for your region and institution. GreenCampus has no sensor connection or real campus database.</div></div>;
}

function Calculator({ onAdd, onRemove, records }: { onAdd: (record: ActivityRecord) => void; onRemove: (id: string) => void; records: ActivityRecord[] }) {
  const [category, setCategory] = useState<Category>('transport');
  const [quantity, setQuantity] = useState('');
  const [mode, setMode] = useState('bus');
  const [date, setDate] = useState(today);
  const [label, setLabel] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const parsed = Number(quantity);
  const factor = category === 'transport' ? (mode === 'walking' || mode === 'cycling' ? 0 : mode === 'car' ? 0.192 : mode === 'motorcycle' ? 0.103 : FACTORS.transport) : FACTORS[category];
  const result = Number.isFinite(parsed) && parsed > 0 ? round(parsed * factor) : 0;
  const units = category === 'transport' ? 'km' : category === 'electricity' ? 'kWh' : 'kg';
  const factorUnit = category === 'transport' ? `kg CO₂e / km · ${mode}` : category === 'electricity' ? 'kg CO₂e / kWh' : 'kg CO₂e / kg';
  const submit = (e: FormEvent) => {
    e.preventDefault();
    const value = Number(quantity);
    if (!quantity.trim() || !Number.isFinite(value) || value <= 0) { setError('Enter a finite amount greater than zero.'); setSuccess(''); return; }
    if (!date || Number.isNaN(Date.parse(date)) || date > today) { setError('Choose a valid date that is today or earlier.'); setSuccess(''); return; }
    if (!Number.isFinite(value * factor)) { setError('That amount is too large to calculate. Enter a smaller value.'); setSuccess(''); return; }
    const rec: ActivityRecord = { id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`, category, quantity: value, ...(category === 'transport' ? { mode } : {}), label: label.trim(), date, emissions: round(value * factor), unit: units, factor };
    onAdd(rec); setQuantity(''); setLabel(''); setDate(today); setError(''); setSuccess(`Saved ${fmt(rec.emissions)} kg CO₂e. Your dashboard has been updated.`);
  };
  const title = category === 'transport' ? 'Log a commute' : category === 'electricity' ? 'Log electricity use' : 'Log waste';
  return <>
    <PageHeading eyebrow="Everyday choices" title="Carbon calculator" subtitle="Add a real activity. See its estimated impact right away." />
    <div className="gc-form-layout">
      <form className="gc-card gc-form-card" onSubmit={submit} noValidate>
        <div className="gc-card-head"><div><h2 className="gc-card-title">{title}</h2><div className="gc-card-caption">Entries are kept in this browser only.</div></div><Activity size={18} color="#5e8966" /></div>
        <div className="gc-tabs" role="tablist" aria-label="Activity category">
          {CATEGORIES.map(({ id, name, icon: Icon }) => <button key={id} type="button" role="tab" aria-selected={category === id} className={`gc-tab ${category === id ? 'active' : ''}`} onClick={() => { setCategory(id); setError(''); setSuccess(''); }} data-testid={`tab-${id}`}><Icon size={14} style={{ verticalAlign: 'middle', marginRight: 6 }} />{name}</button>)}
        </div>
        <div className="gc-fields">
          {category === 'transport' && <div className="gc-field full"><label htmlFor="transport-mode">How did you travel?</label><select id="transport-mode" value={mode} onChange={(e) => setMode(e.target.value)} data-testid="select-transport-mode">
            <option value="bus">Bus</option><option value="car">Car</option><option value="motorcycle">Motorcycle</option><option value="walking">Walking</option><option value="cycling">Cycling</option>
          </select><span className="gc-field-help">Choose the mode used for the day’s travel.</span></div>}
          <div className="gc-field"><label htmlFor="activity-quantity">{category === 'transport' ? 'Daily distance travelled (km)' : category === 'electricity' ? 'Electricity used (kWh)' : 'Waste generated (kg)'}</label>
            <input id="activity-quantity" type="number" inputMode="decimal" min="0" step="any" value={quantity} onChange={(e) => { setQuantity(e.target.value); if (error) setError(''); }} placeholder={category === 'transport' ? 'e.g. 4.5' : category === 'electricity' ? 'e.g. 2.8' : 'e.g. 1.2'} aria-invalid={Boolean(error)} aria-describedby={error ? 'activity-error' : 'quantity-help'} data-testid="input-activity-quantity" />
            <span className="gc-field-help" id="quantity-help">A number greater than zero. {category === 'transport' ? 'Enter the total kilometres travelled today.' : 'Use the amount for this activity.'}</span>
            {error && <span id="activity-error" className="gc-error" role="alert">{error}</span>}</div>
          <div className="gc-field"><label htmlFor="activity-date">Activity date</label><input id="activity-date" type="date" value={date} max={today} onChange={(e) => setDate(e.target.value)} data-testid="input-activity-date" /></div>
          <div className="gc-field full"><label htmlFor="activity-label">Label <span style={{ fontWeight: 400, color: '#92a096' }}>· optional</span></label><input id="activity-label" value={label} onChange={(e) => setLabel(e.target.value)} maxLength={50} placeholder={category === 'transport' ? 'e.g. Morning commute' : category === 'electricity' ? 'e.g. Studio lights' : 'e.g. Lunch packaging'} data-testid="input-activity-label" /></div>
        </div>
        <div className="gc-calc-result"><div className="gc-kpi-label"><Leaf size={14} /> Estimated emissions</div><div className="gc-result-number" data-testid="value-calculated-emissions">{fmt(result)} <span className="gc-kpi-unit">kg CO₂e</span></div><div className="gc-kpi-foot">{fmt(Number.isFinite(parsed) ? parsed : 0)} {units} × {factor} {factorUnit}</div></div>
        {error && <div role="alert" className="gc-error" style={{ marginTop: 12 }} data-testid="status-form-error">{error}</div>}
        {success && <div role="status" className="gc-success" data-testid="status-activity-saved"><Check size={14} style={{ verticalAlign: 'middle', marginRight: 5 }} />{success}</div>}
        <div className="gc-submit-row"><button type="button" className="gc-quiet-btn" onClick={() => { setQuantity(''); setLabel(''); setError(''); setSuccess(''); setDate(today); }} data-testid="button-reset-form">Reset</button><button type="submit" className="gc-primary-btn" data-testid="button-save-activity"><Plus size={15} /> Save activity</button></div>
      </form>
      <aside className="gc-card gc-side-panel">
        <div className="gc-card-head"><div><h2 className="gc-card-title">What’s behind the number?</h2><div className="gc-card-caption">Illustrative factors used in this demo</div></div><CircleHelp size={17} color="#76927d" /></div>
        <div className="gc-factor-list">
          <div className="gc-factor"><span>Bus travel</span><strong>0.089 kg / km</strong></div>
          <div className="gc-factor"><span>Car travel</span><strong>0.192 kg / km</strong></div>
          <div className="gc-factor"><span>Motorcycle</span><strong>0.103 kg / km</strong></div>
          <div className="gc-factor"><span>Walking / cycling</span><strong>0 kg / km</strong></div>
          <div className="gc-factor"><span>Electricity</span><strong>0.42 kg / kWh</strong></div>
          <div className="gc-factor"><span>Waste</span><strong>0.58 kg / kg</strong></div>
        </div>
        <div className="gc-notice"><ShieldCheck size={15} style={{ flexShrink: 0, marginTop: 1 }} /><div>Factors are illustrative estimates, not verified local values. Ask your campus sustainability team for region-specific factors before making formal claims.</div></div>
        <div className="gc-card-caption" style={{ lineHeight: 1.6 }}>Saved entries: <strong style={{ color: '#3a5e45' }} data-testid="value-saved-count">{records.length}</strong> · Stored only in local browser storage</div>
      </aside>
    </div>
    <div className="gc-card" style={{ marginTop: 16 }}>
      <div className="gc-card-head"><div><h2 className="gc-card-title">Your activity log</h2><div className="gc-card-caption">Remove any entry to revise your running estimate.</div></div></div>
      {!records.length ? <div className="gc-empty"><div className="gc-empty-mark"><Leaf size={18} /></div>Your saved activities will appear here.</div> : records.map((r) => <ActivityRow key={r.id} record={r} onRemove={onRemove} />)}
    </div>
    <EstimatesNotice />
  </>;
}

function Insights({ records, totals, total, score }: { records: ActivityRecord[]; totals: Record<Category, number>; total: number; score: number }) {
  const pie = CATEGORIES.map((c) => ({ name: c.name, value: round(totals[c.id]), color: c.color })).filter((x) => x.value > 0);
  const history = useMemo(() => records.reduce<Record<string, { date: string; transport: number; electricity: number; waste: number }>>((acc, r) => {
    if (!acc[r.date]) acc[r.date] = { date: r.date, transport: 0, electricity: 0, waste: 0 };
    acc[r.date][r.category] += r.emissions; return acc;
  }, {}), [records]);
  const trend = Object.values(history).sort((a, b) => a.date.localeCompare(b.date)).slice(-14).map((x) => ({ ...x, day: new Date(`${x.date}T12:00:00`).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }), total: round(x.transport + x.electricity + x.waste) }));
  return <>
    <PageHeading eyebrow="Patterns, not perfection" title="Campus insights" subtitle="Understand the shape of your log and where small changes can matter." />
    <div className="gc-kpis" style={{ gridTemplateColumns: 'repeat(3,1fr)' }}>
      <div className="gc-card"><div className="gc-kpi-label"><Cloud size={14} /> Total estimate</div><div className="gc-kpi-value" data-testid="value-insights-total">{fmt(total)} <span className="gc-kpi-unit">kg</span></div><div className="gc-kpi-foot">Across {records.length} logged activities</div></div>
      <div className="gc-card"><div className="gc-kpi-label"><Activity size={14} /> Most logged category</div><div className="gc-kpi-value" style={{ fontSize: 22 }}>{records.length ? CATEGORIES.reduce((a, b) => records.filter((r) => r.category === a.id).length >= records.filter((r) => r.category === b.id).length ? a : b).name : 'Not yet'}</div><div className="gc-kpi-foot">By estimated emissions</div></div>
      <div className="gc-card"><div className="gc-kpi-label"><Sprout size={14} /> Engagement score</div><div className="gc-kpi-value">{score}<span className="gc-kpi-unit"> / 100</span></div><div className="gc-kpi-foot">A simple in-app indicator</div></div>
    </div>
    <div className="gc-insights-grid">
      <div className="gc-card"><div className="gc-card-head"><div><h2 className="gc-card-title">Estimated emissions mix</h2><div className="gc-card-caption">By logged category · kg CO₂e</div></div></div>
        {!pie.length ? <div className="gc-empty"><div className="gc-empty-mark"><BarChart3 size={18} /></div>Once you add activities, the category mix will appear here.</div> : <div style={{ height: 220, display: 'flex', alignItems: 'center' }}>
          <div style={{ width: '58%', height: '100%' }}><ResponsiveContainer width="100%" height="100%"><PieChart><Pie data={pie} dataKey="value" nameKey="name" innerRadius={57} outerRadius={85} paddingAngle={3} stroke="none">{pie.map((x) => <Cell key={x.name} fill={x.color} />)}</Pie><ChartTooltip formatter={(v: number) => [`${fmt(v)} kg CO₂e`, 'Estimate']} /></PieChart></ResponsiveContainer></div>
          <div style={{ display: 'grid', gap: 13 }}>{CATEGORIES.map((c) => <div key={c.id} className="gc-legend"><span className="gc-dot" style={{ background: c.color }} />{c.name}<strong style={{ marginLeft: 4, color: '#355a42' }}>{fmt(totals[c.id])}</strong></div>)}</div>
        </div>}
      </div>
      <div className="gc-card"><div className="gc-card-head"><div><h2 className="gc-card-title">Category contributions</h2><div className="gc-card-caption">Share of your estimated footprint</div></div></div>
        {CATEGORIES.map((c) => <div className="gc-breakdown-row" key={c.id}><span>{c.name}</span><div className="gc-bar-track"><div className="gc-bar-fill" style={{ width: `${total ? Math.max(1, totals[c.id] / total * 100) : 0}%`, background: c.color }} /></div><strong style={{ color: '#3e6148', textAlign: 'right' }}>{total ? `${Math.round(totals[c.id] / total * 100)}%` : '—'}</strong></div>)}
        {!records.length && <div className="gc-empty" style={{ paddingTop: 10 }}>Log an activity to explore your category mix.</div>}
      </div>
      <div className="gc-card gc-wide"><div className="gc-card-head"><div><h2 className="gc-card-title">Your log over time</h2><div className="gc-card-caption">Daily logged estimates · kg CO₂e</div></div></div>
        {!trend.length ? <div className="gc-empty"><div className="gc-empty-mark"><CalendarDays size={18} /></div>No trend to show yet. Start with an everyday activity.</div> : <div className="gc-chart-wrap" style={{ height: 235 }}><ResponsiveContainer width="100%" height="100%"><BarChart data={trend} margin={{ top: 5, right: 10, left: -18, bottom: 0 }}><CartesianGrid stroke="#edf1ed" vertical={false} /><XAxis dataKey="day" axisLine={false} tickLine={false} tick={{ fill: '#8b998e', fontSize: 10 }} /><YAxis axisLine={false} tickLine={false} tick={{ fill: '#8b998e', fontSize: 9 }} /><ChartTooltip formatter={(v: number) => [`${fmt(v)} kg CO₂e`, '']} contentStyle={{ borderRadius: 9, border: '1px solid #e1eae2', fontSize: 11 }} />{CATEGORIES.map((c) => <Bar key={c.id} dataKey={c.id} name={c.name} stackId="a" fill={c.color} radius={[2, 2, 0, 0]} />)}</BarChart></ResponsiveContainer></div>}
      </div>
    </div>
    <div className="gc-notice" role="note"><ShieldCheck size={15} style={{ flexShrink: 0 }} /><div><strong>Read these as estimates.</strong> Results depend on illustrative factors and activities you entered. Missing data does not mean zero real-world emissions. This is not an official inventory or verified campus comparison.</div></div>
  </>;
}

function About() {
  return <>
    <PageHeading eyebrow="Why GreenCampus exists" title="Sustainability, made practical." subtitle="A useful place to notice everyday choices—and make the next one a little better." />
    <section className="gc-about-hero"><div className="gc-eyebrow" style={{ color: '#a9d8b3' }}>A shared campus picture</div><h2>Progress starts with seeing the choices we make.</h2><p>GreenCampus turns simple activity notes into an approachable estimate of transport, electricity, and waste. No specialist dashboard. No perfect data required. Just a starting point for better conversations.</p></section>
    <section className="gc-about-grid">
      <div className="gc-card gc-about-point"><span className="gc-empty-mark"><BusFront size={18} /></span><h3>Everyday activity</h3><p>Log the commute you took, electricity you used, or waste you generated. Small, specific entries are easier to act on than a distant annual total.</p></div>
      <div className="gc-card gc-about-point"><span className="gc-empty-mark"><BarChart3 size={18} /></span><h3>Shared understanding</h3><p>See category estimates and changing patterns in one place. The sample leaderboard is illustrative only—not a campus ranking or a record of real groups.</p></div>
      <div className="gc-card gc-about-point"><span className="gc-empty-mark"><Lightbulb size={18} /></span><h3>Useful next steps</h3><p>Get practical suggestions based on the largest category in your log. Choose one change that fits your day and build from there.</p></div>
    </section>
    <section className="gc-card" style={{ marginTop: 16 }}>
      <div className="gc-card-head"><div><h2 className="gc-card-title">How the estimate works</h2><div className="gc-card-caption">A transparent calculation—not a black box</div></div><ShieldCheck size={18} color="#598365" /></div>
      <p style={{ color: '#687d6e', fontSize: 12, lineHeight: 1.8, margin: '0 0 14px' }}>For each entry, activity quantity is multiplied by an illustrative emissions factor. The factors shown in the calculator are demonstration values, not verified local values. Ask your institution to replace them with documented, region-appropriate factors before using results in formal reporting. The demo score is based on the number of activities and category coverage; it does not measure verified reductions.</p>
      <div className="gc-notice" style={{ marginBottom: 0 }}><CircleHelp size={15} style={{ flexShrink: 0 }} /><div><strong>Honest by design.</strong> GreenCampus does not connect to campus sensors, utility meters, transport feeds, or a real campus database. Your entries are stored in your browser's local storage and stay on this device.</div></div>
    </section>
    <div className="gc-card" style={{ marginTop: 16, display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 14, flexWrap: 'wrap' }}><div><div className="gc-card-title">Ready to start your campus estimate?</div><div className="gc-card-caption">Add an activity and see the dashboard update instantly.</div></div><Link href="/calculator" className="gc-primary-btn" data-testid="link-about-calculator"><Plus size={15} /> Log your first activity</Link></div>
  </>;
}

export default App;
